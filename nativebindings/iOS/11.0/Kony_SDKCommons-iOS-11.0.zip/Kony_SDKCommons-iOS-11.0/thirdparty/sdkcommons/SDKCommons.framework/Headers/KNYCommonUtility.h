//
//  KNYCommonUtility.h
//  SDKCommons
//
//  Created by Archana Narahari on 27/12/17.
//  Copyright © 2017 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KNYCommonUtility : NSObject

+ (BOOL)isObjectNilOrNull:(id)object;

+ (BOOL)isValidString:(id)object;

+ (BOOL)isValidBool:(id)object;

+ (BOOL)isArrayValidAndNotEmpty:(NSArray *)array;

+ (BOOL)isDictionaryValidAndNotEmpty:(NSDictionary *)dictionary;
@end
